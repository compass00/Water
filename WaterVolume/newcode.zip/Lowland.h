//
//  Lowland.h
//  WaterVolume
//
//  Created by JiaLi on 16/4/13.
//  Copyright © 2016年 JiaLi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Brick.h"

@interface Lowland : Brick

@end
