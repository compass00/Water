//
//  Lowland.m
//  WaterVolume
//
//  Created by JiaLi on 16/4/13.
//  Copyright © 2016年 JiaLi. All rights reserved.
//

#import "Lowland.h"

@implementation Lowland

- (id) init {
    self = [super init];
    self.type = WVType_Lowland;
    return self;
}


@end
